package com.example.camunda.workers;

import io.camunda.zeebe.client.ZeebeClient;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

@Component
public class FileReaderWorker {
    private final ZeebeClient client;

    public FileReaderWorker(ZeebeClient client) {
        this.client = client;
        client.newWorker().jobType("read-file").handler((jobClient, job) -> {
            String filePath = (String) job.getVariablesAsMap().get("filePath");
            try {
                List<String> lines = Files.readAllLines(Paths.get(filePath));
                jobClient.newCompleteCommand(job.getKey())
                        .variables(Map.of("data", lines))
                        .send()
                        .join();
            } catch (IOException e) {
                throw new RuntimeException("Failed to read file", e);
            }
        }).open();
    }
}
